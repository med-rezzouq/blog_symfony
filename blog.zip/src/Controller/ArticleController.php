<?php

declare(strict_types=1);

namespace App\Controller;

use App\Entity\Article;
use App\Entity\Comment;
use App\Form\Type\ArticleType;
use App\Form\Type\CommentType;
use App\Repository\ArticleRepository;
use App\Repository\CommentRepository;
use App\Service\ArticleManager;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Entity;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use DateTimeImmutable;

#[Route('/article')]
class ArticleController extends AbstractController
{
    #[Route('/{articleId}', name: 'app_single_article', priority: 1)]
    #[Entity('article', options: ['mapping' => ['articleId' => 'slug']])]
    public function single(Request $request, Article $article, ArticleManager $articleManager, CommentRepository $commentRepository): Response
    {

        dump($request->getSession()->get('_security.last_username'));
        $related = $articleManager->getRelatedArticles($article->getCategory()->getId());
        // dump($related);
        $comment = new Comment();
        $form = $this->createForm(CommentType::class, $comment);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // $var = $form->get('test')->getData();

            if (null !== $this->getUser()) {
                $comment->setName($this->getUser()->getUsername());
                $comment->setEmail($this->getUser()->getEmail());
                $comment->setVisible(false);
            } else if (null !== $request->getSession()->get('_security.last_username')) {
                $comment->setName($request->getSession()->get('name'));
                $comment->setEmail($request->getSession()->get('_security.last_username'));
                $comment->setVisible(false);
                //setting the user session
            } else if (null === $request->getSession()->get('_security.last_username') && null === $this->getUser()) {
                $request->getSession()->set('_security.last_username', $comment->getEmail());
                $request->getSession()->set('name', $comment->getName());
                $comment->setVisible(false);
            }
            $comment->setArticle($article);


            $article->setDateOfCreation(new DateTimeImmutable());
            $commentRepository->save($comment, true);
            $flashBag = $request->getSession()->getFlashBag();

            // Clear any previous messages
            $flashBag->clear();
            $this->addFlash('warning', 'Your comment is under review');

            return $this->redirectToRoute('app_single_article', ['articleId' => $article->getSlug()]);
        }

        return $this->render('article/single.html.twig', [
            'article' => $article,
            'related' => $related,
            'addCommentForm' => $form->createView()
        ]);
    }

    #[Route('/add', name: 'app_add_article', priority: 2)]
    #[IsGranted('ROLE_USER')]
    public function add(Request $request, ArticleRepository $articleRepository)
    {
        // $this->denyAccessUnlessGranted("ROLE_ADMIN");
        $article = new Article();
        $form = $this->createForm(ArticleType::class, $article);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            // $var = $form->get('test')->getData();
            $article->setUser($this->getUser());
            $article->setDateOfCreation(new DateTimeImmutable());
            $articleRepository->save($article, true);
            $flashBag = $request->getSession()->getFlashBag();

            // Clear any previous messages
            $flashBag->clear();
            $this->addFlash('success', 'Article saved successfully');

            return $this->redirectToRoute('app_add_article');
        }

        return $this->render(
            'Article/add.html.twig',
            ['addArticleForm' => $form->createView()]
        );
    }
}
